@echo off
title KUKA KRL Editor - Installation
echo.
echo  ==========================================
echo   KUKA KRL Editor - Kostenlos / Free
echo   CAD/CAM Systeme Datentechnik Reitz
echo  ==========================================
echo.
echo  Erstelle Desktop-Verknuepfung...
echo.

set SHORTCUT=%USERPROFILE%\Desktop\KRL Editor.url
echo [InternetShortcut] > "%SHORTCUT%"
echo URL=https://cnc-technik.de/kuka >> "%SHORTCUT%"

echo  Desktop-Verknuepfung erstellt!
echo.
echo  Oeffne KRL Editor im Browser...
start "" "https://cnc-technik.de/kuka"
echo.
echo  Installation abgeschlossen!
pause
