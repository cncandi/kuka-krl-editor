KUKA KRL Editor - Free / Kostenlos
===================================
CAD/CAM Systeme Datentechnik Reitz GmbH
https://cnc-technik.de

INSTALLATION (Windows):
  Doppelklick auf: Install-KRL-Editor.bat
  -> Erstellt Desktop-Verknuepfung
  -> Oeffnet den Editor im Browser

DIREKTER AUFRUF:
  Doppelklick auf: KRL-Editor.url
  oder: https://cnc-technik.de/kuka

FUNKTIONEN:
  - Syntax Highlighting fuer KRL
  - Code Completion (IntelliSense)
  - Go to Definition (F12)
  - WorkVisual .wvs/.wvps Support
  - 6 Programmtypen-Vorlagen
  - Community-Bibliothek
  - 100% kostenlos, keine Registrierung

GitHub: https://github.com/cncandi/kuka-krl-editor
